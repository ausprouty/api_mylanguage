<?php

return [
    // Environment-specific settings
    'environment' => 'remote',

    /**
     * CORS (authoritative)
     * 
     */
    'cors' => [
        // EXACTLY the domains you currently allow on remote:
        'allowed_origins' => [
            'https://hereslife.com',
            'https://api.hereslife.com',
            'https://dbs.mylanguage.net.au',
            'https://guru.mylanguage.net.au',
            'https://uom.mylanguage.net.au',
            'https://wisdom.mylanguage.net.au',
            'https://wsu.mylanguage.net.au',
        ],
        // Only set true if you truly need cookie/credentialed CORS
        'allow_credentials' => false,
        'allowed_methods'   => ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
        'allowed_headers'   => ['Content-Type','Authorization','X-Requested-With'],
        'exposed_headers'   => [],
        // Only paths that actually require cross-origin access
        'require_origin_paths' => ['/api/*'],
        // Cache preflight a day
        'max_age' => 86400,
    ],

    /**
     * Database Configuration
     */
    'databases' => [
        'standard' => [
            'DB_HOST' => 'localhost',
            'DB_DATABASE' => 'mylanguagenet_api2',
            'DB_USERNAME' => 'mylanguagenet_api',
            'DB_PASSWORD' => 'm;8Ewj(#f1O(',
            'WEB_PORT' => '443',
            'DB_PORT' => 3306,
            'DB_CHARSET' => 'utf8mb4',
            'DB_COLLATION' => 'utf8mb4_unicode_ci',
            'PREFIX' => '',
        ],
    ],

    /**
     * Bible Study Names
     */
    'bible_study_names' => [
        'ctc' => 'Creation to Community',
        'lead' => 'Leadership',
        'life' => 'LifePrinciple',
    ],

     /**
     * Charset and Collation Settings
     */
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',

     /**
     * URL and Dir Configuration
     */
    'base_path'=>'/',
    'base_url' => 'https://api2.mylanguage.net.au/',
    'base_dir' => '/home/mylanguagenet/api2.mylanguage.net.au/',

    /**
     * Path Configuration
     */
    'paths' => [
        'imports' => 'imports/data/',
        'logs' =>'App/Logs/',
        'libraries' => 'App/Libraries/',
        'resources' => [
            'bibles' => 'Resources/bibles/',
            'bible_studies' => 'Resources/bibleStudies/',
            'bible_studies_pdf' => 'Resources/bibleStudies/pdf/',
            'bible_studies_view' => 'Resources/bibleStudies/view/',
            'bible_studies_other' => 'Resources/bibleStudies/other/',
            'bible_tracts' => 'Resources/bibleTracts/',
            'fonts' => 'Resources/fonts/',
            'images' => 'Resources/images/',
            'maps' => 'Resources/maps/',
            'qr_codes' => 'Resources/qrCodes/',
            'root'=> 'Resources/',
            'templates' => 'Resources/templates/',
            'translations' => 'Resources/translations/',
            'styles' => 'Resources/styles/',
        ],
        'twig_cache' => 'Resources/templates/cache/',
        'vendor' => 'vendor/',
    ],

    /**
     * Logging Configuration
     */
    'logging' => [
        'mode'     => 'write_log',     // keep your current mode
        'level'    => 'warning',       // debug|info|warning|error|critical
        'file'     => 'application.log',     // used for web requests
        'cli_file' => 'translation-a.log',   // used for cron (optional)
        'log_mirror_error_log'=> true,
        'blank_line_between' => true, // default is true even if omitted
        'i18n_debug' => true,
    ],
    
    /**
    *  EndPoints
    */

    'endpoints'=>[
       'biblebrain' => 'https://4.dbt.io', // no trailing /api here; the service adds it
       'biblegateway' =>'https://www.biblegateway.com',
       'wordproject' => 'https://wordproject.org/bibles/',
       'cloudfront'=> 'https://d0000000000000.cloudfront.net',
       'youversion'=> 'https://www.bible.com/bible/'
    ],

    /**
    *  i18n Settings
    */
    
     'i18n' => [
        'baseLanguage'          => 'en',
        'autoMt'=> [
            'enabled'        => true,
            'allowGoogle'       => [],
            'provider'       => 'google'  // or null
        ],
        // we never translate this section of a template 
        // (unless the meta section of the template says otherwise)
        'exclude_keys_default' => ['meta', 'video'],
        // Force a short worker run after enqueue, even in prod.
        // Typically leave false; flip true to immediately process.
        'force_kick'             => true,

        // How long the forced kick should run (seconds) and
        // how many jobs it should try to take (batch size).
        'force_kick_seconds'     => 10,
        'force_kick_batch'       => 25,

        // Auto-kick when enqueuing in dev/local environments.
        // Great for tight feedback loops.
        'kick_on_enqueue_dev'    => true,
        // Auto-kick when enqueuing in prod/remote.
        // Usually false—cron should handle prod.
        'kick_on_enqueue_prod'   => true,

        // Optional overrides (usually leave null):
        // If set, use this absolute bin dir for runners.
        'kick_bin_dir'           => null,
        // If set, force a specific runner: 'dev' or 'prod',
        // or an absolute path to a PHP script.
        'kick_runner'            => null,
    ],

    /**
     * API Configuration
     */
    'api' => [
        'jvideo_player' => 'https://api.arclight.org/videoPlayerUrl?refId=',
        'dbt_key' => '3d116e49d7d98c6e20bf0f4a9c88e4cc',
        'bible_brain_key' => '1462b719-42d8-0874-7c50-905063472458',
        'azure_subscription_key' => '0b63f7a5a13e4f20ac59838ccd6d0bf1',
        'google_translate_apiKey' => 'AIzaSyAKfNICKaAhewcrKDhmGPabuV0o_HbDsVI',
        'google_project_id'=> 'mylanguage-translate',
        'youtube_api_key'=> 'AIzaSyBti8NQFeobv0Ivw0Lw4qqd-nvwNCMR7P0',
        'cron_key'=> 'CKaAhewcrKDh'
    ],

    /**
     * Security Settings
     */
    'security' => [
        'acceptable_ip' => '*',
    ],
];
