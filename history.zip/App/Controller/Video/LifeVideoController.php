<?php
namespace App\Controller\Video;

class LifeVideoController extends Video
{

}
