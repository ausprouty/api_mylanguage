<?php

namespace App\Controller\BiblePassage\BibleBrain;

use App\Controller\BiblePassage\BibleBrain\BibleBrainPassageController;

class BibleBrainTextUSXController extends BibleBrainPassageController
{
    
}