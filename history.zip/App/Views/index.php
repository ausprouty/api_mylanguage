<?php


echo ("Access /local or /remote for index");