<?php
namespace App\Model;

class Authorize{


    static function authorized($post){
        return true;
    }
}