<?php
echo "how are you?";