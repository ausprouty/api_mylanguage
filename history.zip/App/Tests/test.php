<?php

use App\Controller\BiblePassage\BibleBrain\BibleBrainLanguageController as BibleBrainLanguageController;

echo ('look at getlanguageDetails-46 ');
$test = new BibleBrainLanguageController();
$test->getlanguageDetails('bng');

