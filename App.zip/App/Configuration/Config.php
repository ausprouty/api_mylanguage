<?php

namespace App\Configuration;

use Exception;

class Config
{
    private static $config = null;

    /**
     * Initialize the configuration by detecting the environment
     * and loading the appropriate configuration file.
     */
    public static function initialize(): void
    {
        if (self::$config !== null) {
            // Config has already been initialized
            return;
        }

        // Detect environment based on server name
        $environment = (in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1']))
            ? 'local'
            : 'remote';

        // Load the appropriate configuration file
        $configFile = __DIR__ . ($environment === 'local' ? '/.env.local.php' : '/.env.remote.php');

        if (!file_exists($configFile)) {
            throw new Exception("Configuration file '{$configFile}' not found.");
        }

        self::$config = require $configFile;

        if (!is_array(self::$config)) {
            throw new Exception("Configuration file '{$configFile}' must return an array.");
        }
    }

    /**
     * Get a configuration value.
     *
     * @param string $key The configuration key. Supports dot notation for nested arrays.
     * @param mixed $default Optional default value if the key is not found.
     * @return mixed The configuration value or the provided default if the key is missing.
     * @throws Exception if a required configuration key is missing and no default is provided.
     */
    public static function get(string $key, $default = null)
    {
        if (self::$config === null) {
            self::initialize(); // Automatically initialize if not already done
        }

        $keys = explode('.', $key);
        $value = self::$config;

        foreach ($keys as $keyPart) {
            if (!isset($value[$keyPart])) {
                if ($default !== null) {
                    error_log("Warning: Configuration key '{$key}' is not defined. Using default value.");
                    return $default;
                }

                throw new Exception("Configuration key '{$key}' is required but not defined.");
            }
            $value = $value[$keyPart];
        }

        return $value;
    }
    public static function getDir($key, $default = null)
    {
        // Ensure the key is valid
        if (!is_string($key) || trim($key) === '') {
            throw new \InvalidArgumentException("Invalid key provided for Config::getDir()");
        }

        // Retrieve the path from configuration
        $path = self::get("paths.$key", $default);

        if (!$path) {
            if ($default !== null) {
                return self::get('base_dir') . $default;
            }
            throw new \InvalidArgumentException("Directory path for '$key' not found.");
        }

        return self::get('base_dir') . $path;
    }


    public static function getUrl($key)
    {
        $path = self::get("paths.$key");
        if (!$path) {
            throw new \InvalidArgumentException("URL for '$key' not found.");
        }

        return self::get('base_url') . $path;
    }
}
