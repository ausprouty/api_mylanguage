<?php

return [
    // Environment-specific settings
    'environment' => 'remote',

    // CORS configuration
    'accepted_origins' => [
        'https://hereslife.com',
        'https://api.hereslife.com',
        'https://wisdom.mylanguage.net.au',
        'https://wisdom2.mylanguage.net.au',
        'https://dbs.mylanguage.net.au'
    ],

    /**
     * Database Configuration
     */
    'databases' => [
        'standard' => [
            'DB_HOST' => 'localhost',
            'DB_DATABASE' => 'mylanguagenet_api2',
            'DB_USERNAME' => 'mylanguagenet_api',
            'DB_PASSWORD' => 'm;8Ewj(#f1O(',
            'WEB_PORT' => '90',
            'DB_PORT' => 3306,
            'DB_CHARSET' => 'utf8',
            'DB_COLLATION' => 'utf8_general_ci',
            'PREFIX' => '',
        ],
    ],

    /**
     * Bible Study Names
     */
    'bible_study_names' => [
        'dbs' => 'DBS',
        'lead' => 'Leadership',
        'life' => 'LifePrinciple',
    ],

     /**
     * Charset and Collation Settings
     */
    'charset' => 'utf8_general_ci',
    'collation' => 'utf8_general_ci',

 /**
     * URL and Dir Configuration
     */
    'base_path'=>'/',
    'base_url' => 'api2.mylanguage.net.au/',
    'base_dir' => '/home/mylanguagenet/api2.mylanguage.net.au/',

    /**
     * Path Configuration
     */
    'paths' => [
        'imports' => 'imports/data/',
        'logs' =>'App/Logs/',
        'libraries' => 'App/Libraries/',
        'resources' => [
            'bibles' => 'Resources/bibles/',
            'bible_studies' => 'Resources/bibleStudies/',
            'bible_studies_pdf' => 'Resources/bibleStudies/pdf/',
            'bible_studies_view' => 'Resources/bibleStudies/view/',
            'bible_studies_other' => 'Resources/bibleStudies/other/',
            'bible_tracts' => 'Resources/bibleTracts/',
            'fonts' => 'Resources/fonts/',
            'images' => 'Resources/images/',
            'maps' => 'Resources/maps/',
            'qr_codes' => 'Resources/qrCodes/',
            'root'=> 'Resources/',
            'translations' => 'Resources/translations/',
            'styles' => 'Resources/styles/',
            'templates' => 'Resources/templates/',
        ],
        'twig_cache' => 'Resources/templates/cache/',
        'vendor' => 'Vendor/',
    ],

    /**
     * Logging Configuration
     */
    'logging' => [
        'mode' => 'write_log',
    ],

    /**
     * API Configuration
     */
    'api' => [
        'jvideo_player' => 'https://api.arclight.org/videoPlayerUrl?refId=',
        'dbt_key' => '3d116e49d7d98c6e20bf0f4a9c88e4cc',
        'bible_brain_key' => '1462b719-42d8-0874-7c50-905063472458',
        'azure_subscription_key' => '0b63f7a5a13e4f20ac59838ccd6d0bf1',
    ],

    /**
     * Security Settings
     */
    'security' => [
        'acceptable_ip' => '*',
    ],
];
