<?php

use DI\ContainerBuilder;

// Create a container builder instance
$containerBuilder = new ContainerBuilder();

// Enable autowiring for most dependencies
$containerBuilder->useAutowiring(true);

// all needs to be first because it failed somewhere and left off one of these
$containerBuilder->addDefinitions(__DIR__ . '/di/di-all.php');
//$containerBuilder->addDefinitions(__DIR__ . '/di/di-config.php');
//$containerBuilder->addDefinitions(__DIR__ . '/di/di-factories.php');
//$containerBuilder->addDefinitions(__DIR__ . '/di/di-models.php');
//$containerBuilder->addDefinitions(__DIR__ . '/di/di-repositories.php');
//$containerBuilder->addDefinitions(__DIR__ . '/di/di-services.php');


// Build the container and return it
return $containerBuilder->build();
